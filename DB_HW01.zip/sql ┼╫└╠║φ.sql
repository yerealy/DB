use yerealiveyoung;
-- 제품 테이블 생성
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50) NOT NULL,
    Category VARCHAR(50) NOT NULL,
    Price DECIMAL(10, 2),
    SupplierID INT,
    InventoryLevel INT
);


-- 재고 테이블 생성
CREATE TABLE Inventory (
    InventoryID INT PRIMARY KEY,
    ProductID INT,
    CurrentInventoryLevel INT,
    StockChangeHistory TEXT,
    StockAlert VARCHAR(50),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);


-- 판매 테이블 생성
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    SaleDate DATE,
    SaleQuantity INT,
    SalePrice DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);


-- 공급업체 테이블 생성
CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY,
    SupplierName VARCHAR(50),
    ContactInformation VARCHAR(50),
    SuppliedProductList TEXT
);
-- 사용자 테이블 생성
CREATE TABLE Users (
    UserID INT PRIMARY KEY,
    UserName VARCHAR(50),
    Role ENUM('admin', 'staff'),
    AccessPermissions VARCHAR(255)
);

-- 외래키 제약 추가
ALTER TABLE Products
ADD FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID);