use yerealiveyoung;
-- 트리거 생성
DELIMITER //
CREATE TRIGGER trg_update_inventory_after_sale
AFTER INSERT ON Sales
FOR EACH ROW
BEGIN
    UPDATE Inventory
    SET CurrentInventoryLevel = CurrentInventoryLevel - NEW.SaleQuantity
    WHERE ProductID = NEW.ProductID;
END;
//
DELIMITER ;

