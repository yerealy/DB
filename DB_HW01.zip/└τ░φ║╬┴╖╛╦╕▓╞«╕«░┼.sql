use yerealiveyoung;
DELIMITER //
CREATE TRIGGER trg_inventory_alert
AFTER UPDATE ON Inventory
FOR EACH ROW
BEGIN
    DECLARE threshold INT DEFAULT 10; /* 임계값 10으로 설정 */
    
    IF NEW.CurrentInventoryLevel < threshold THEN
        UPDATE Inventory
        SET StockAlert = 'Low Stock'
        WHERE InventoryID = NEW.InventoryID;
    ELSE
        UPDATE Inventory
        SET StockAlert = NULL
        WHERE InventoryID = NEW.InventoryID;
    END IF;
END;
//
DELIMITER ;
