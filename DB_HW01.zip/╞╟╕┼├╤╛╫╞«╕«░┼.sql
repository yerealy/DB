USE yerealiveyoung;

DELIMITER //

-- 트리거 생성
CREATE TRIGGER trg_calculate_total_sale
AFTER INSERT ON Sales
FOR EACH ROW
BEGIN
    UPDATE Sales
    SET SaleTotal = NEW.SaleQuantity * NEW.SalePrice
    WHERE SaleID = NEW.SaleID;
END;
//

DELIMITER ;
