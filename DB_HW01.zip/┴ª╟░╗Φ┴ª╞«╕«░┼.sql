use yerealiveyoung;
DELIMITER //

CREATE TRIGGER trg_delete_related_data
AFTER DELETE ON Products
FOR EACH ROW
BEGIN
    DELETE FROM Inventory WHERE ProductID = OLD.ProductID;
    DELETE FROM Sales WHERE ProductID = OLD.ProductID;
END;
//

DELIMITER ;
